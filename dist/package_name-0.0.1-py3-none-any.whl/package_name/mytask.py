print("All good")
